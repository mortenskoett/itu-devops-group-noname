```mermaid
graph LR
   A --> B
   A -->C
   C -->D
``` 
