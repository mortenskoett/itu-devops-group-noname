# Exam report DevOps, spring 2020

<div align="center">

![group logo](images/group_logo_large.png)

Group noname


Emil Budtz-Jørgensen (embu@itu.dk), 
Frank Andersen (fand@itu.dk), 
Liv Hartoft Borre (livb@itu.dk), 
Morten Skøtt Knudsen (mskk@itu.dk), 
Simon Bodekær Black (sibl@itu.dk) 


![Noname Minitwit](images/sc_minitwit_1.png)


 [Table of content](table_of_content.md)

 </div>